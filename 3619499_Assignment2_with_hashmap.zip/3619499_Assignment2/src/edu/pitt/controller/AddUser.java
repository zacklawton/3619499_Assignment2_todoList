package edu.pitt.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddUser implements ActionListener {

	private Controller controller;

	public AddUser(Controller controller) {
		this.controller = controller;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
}
